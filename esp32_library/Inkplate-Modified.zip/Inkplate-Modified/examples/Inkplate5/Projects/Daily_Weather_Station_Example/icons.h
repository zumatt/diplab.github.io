#ifndef ICONS_H
#define ICONS_H

#include "binary_Icons/icon_C.h"
#include "binary_Icons/icon_H.h"
#include "binary_Icons/icon_Hc.h"
#include "binary_Icons/icon_Hr.h"
#include "binary_Icons/icon_Lc.h"
#include "binary_Icons/icon_Lr.h"
#include "binary_Icons/icon_S.h"
#include "binary_Icons/icon_Sl.h"
#include "binary_Icons/icon_Sn.h"
#include "binary_Icons/icon_T.h"

#include "binary_Icons/icon_S_C.h"
#include "binary_Icons/icon_S_H.h"
#include "binary_Icons/icon_S_Hc.h"
#include "binary_Icons/icon_S_Hr.h"
#include "binary_Icons/icon_S_Lc.h"
#include "binary_Icons/icon_S_Lr.h"
#include "binary_Icons/icon_S_S.h"
#include "binary_Icons/icon_S_Sl.h"
#include "binary_Icons/icon_S_Sn.h"
#include "binary_Icons/icon_S_T.h"

#endif

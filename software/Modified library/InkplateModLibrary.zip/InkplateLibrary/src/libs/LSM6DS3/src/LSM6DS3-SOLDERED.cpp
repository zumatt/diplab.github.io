/**
 **************************************************
 *
 * @file        LSM6DS3-SOLDERED.cpp
 * @brief       Header file for LSM6D3 library.
 *
 *
 * @copyright GNU General Public License v3.0
 * @authors     Karlo Leksic for soldered.com
 ***************************************************/


#include "LSM6DS3-SOLDERED.h"

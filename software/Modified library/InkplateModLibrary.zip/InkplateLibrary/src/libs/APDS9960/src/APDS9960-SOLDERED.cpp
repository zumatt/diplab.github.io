/**
 **************************************************
 *
 * @file        APDS9960-SOLDERED.cpp
 * @brief       Intentionally empty
 *
 *
 * @copyright GNU General Public License v3.0
 * @authors     Zvonimir Haramustek for soldered.com
 ***************************************************/


//#include "Generic-easyC-SOLDERED.h"

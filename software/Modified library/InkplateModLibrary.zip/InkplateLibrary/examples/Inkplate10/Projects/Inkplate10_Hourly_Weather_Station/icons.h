#ifndef ICONS_H
#define ICONS_H

#include "binary_Icons/icon_01d.h"
#include "binary_Icons/icon_02d.h"
#include "binary_Icons/icon_03d.h"
#include "binary_Icons/icon_04d.h"
#include "binary_Icons/icon_09d.h"
#include "binary_Icons/icon_10d.h"
#include "binary_Icons/icon_11d.h"
#include "binary_Icons/icon_13d.h"
#include "binary_Icons/icon_50d.h"

#include "binary_Icons/icon_01n.h"
#include "binary_Icons/icon_02n.h"
#include "binary_Icons/icon_03n.h"
#include "binary_Icons/icon_04n.h"
#include "binary_Icons/icon_09n.h"
#include "binary_Icons/icon_10n.h"
#include "binary_Icons/icon_11n.h"
#include "binary_Icons/icon_13n.h"
#include "binary_Icons/icon_50n.h"

#include "binary_Icons/icon_S_01d.h"
#include "binary_Icons/icon_S_02d.h"
#include "binary_Icons/icon_S_03d.h"
#include "binary_Icons/icon_S_04d.h"
#include "binary_Icons/icon_S_09d.h"
#include "binary_Icons/icon_S_10d.h"
#include "binary_Icons/icon_S_11d.h"
#include "binary_Icons/icon_S_13d.h"
#include "binary_Icons/icon_S_50d.h"

#include "binary_Icons/icon_S_01n.h"
#include "binary_Icons/icon_S_02n.h"
#include "binary_Icons/icon_S_03n.h"
#include "binary_Icons/icon_S_04n.h"
#include "binary_Icons/icon_S_09n.h"
#include "binary_Icons/icon_S_10n.h"
#include "binary_Icons/icon_S_11n.h"
#include "binary_Icons/icon_S_13n.h"
#include "binary_Icons/icon_S_50n.h"

#endif

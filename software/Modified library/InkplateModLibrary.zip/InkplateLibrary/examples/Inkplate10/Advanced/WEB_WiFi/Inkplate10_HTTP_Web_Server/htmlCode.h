String s =  "<head>"
            "<title>Soldered Inkplate e-paper display</title>"

            "<style type='text/css'>"

            "textarea {"
            "width: 300px;"
            "height: 5em;"
            "}"

            "textarea {"
            "  font-size: 150%;"
            "}"

            "t1 {"
            "  font-size: 150%;"
            "  font-weight: bold;"
            "}"

            "</style>" 

            "</head>"

            "<body><form action='/string/' method='get' target='_self'><t1>Insert string that you want to display:</t1><br><textarea autofocus maxlength = '100' rows = '7' cols = '30' name = 'input1'>Write some text!</textarea><br>" 

            "<input type='submit' value='Send to display!'></form></body></html>";

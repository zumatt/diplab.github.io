#ifndef ICONS_H
#define ICONS_H

#include "binary_Icons/icon_01d.h"
#include "binary_Icons/icon_02d.h"
#include "binary_Icons/icon_03d.h"
#include "binary_Icons/icon_04d.h"
#include "binary_Icons/icon_09d.h"
#include "binary_Icons/icon_10d.h"
#include "binary_Icons/icon_11d.h"
#include "binary_Icons/icon_13d.h"
#include "binary_Icons/icon_50d.h"

#endif
